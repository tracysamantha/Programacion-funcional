package v3_superfunciones_inline_clases;

import v2_superfunciones_clases.clases.*;
import v3_superfunciones_inline_clases.interfaces.*;

import java.util.ArrayList;
import java.util.List;

public class MainSuperfunciones {

    public static void main(String[] args) {
        new MainSuperfunciones();
    }

    //Constructor
    public MainSuperfunciones() {
        //TODO crear métodos por cada solicitud
        //1. Crear lista de enteros de manera aleatoria
        List<Integer> numerosAzar = Superfunciones.proveer(3, new Proveedor() {
            @Override
            public Integer obtener() {
                return (int) (Math.random() * 100 + 1);
            }
        });
        System.out.println(numerosAzar);
        //2. Filtrar sólo los números pares
        List<Integer> numerosPares = Superfunciones.filtrar(numerosAzar, new Predicado() {
            @Override
            public boolean test(Integer p) {
                return p % 2 == 0;
            }
        });
        System.out.println(numerosPares);
        //3. Convertir los números al cuadrado
        List<Integer> numerosCuadrados = Superfunciones.transformar(numerosPares, new Function() {
            @Override
            public Integer aplicar(Integer numero) {
                return numero * numero;
            }
        });
        System.out.println(numerosCuadrados);

        Consumidor consumidor = new Consumidor() {
            @Override
            public void aceptar(Integer valor) {
                System.out.println(valor);
            }
        };

        //4.a Mostrar cada cuadrado por pantalla que retorna
        List<Integer> numerosMostrados = Superfunciones.actuar(numerosCuadrados, consumidor);
        //4.b Mostrar cada cuadrado por pantalla sin retorno
        Superfunciones.consumir(numerosCuadrados, consumidor);
        //5. Obtener la suma de los cuadrados
        int sumatoria = Superfunciones.reducir(numerosMostrados, 0, new FuncionBinaria() {
            @Override
            public Integer aplicar(Integer valor1, Integer valor2) {
                return  valor1 + valor2;
            }
        });//sumarLista(numerosMostrados);
        System.out.println("Suma total : " + sumatoria);
    }

    //1. Crear lista de enteros de manera aleatoria

    private List<Integer> crearLista() {

        List<Integer> numeros = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            numeros.add((int) (Math.random() * 100 + 1));
        }

        return numeros;
    }

    private List<Integer> getPares(List<Integer> numeros) {
        List<Integer> resultado = new ArrayList<>();

        for (Integer numero : numeros) {
            if (numero % 2 == 0) {
                resultado.add(numero);
            }
        }

        return resultado;
    }

    private List<Integer> calcularCuadrado(List<Integer> numeros) {
        List<Integer> resultado = new ArrayList<>();

        for (Integer num : numeros) {
            resultado.add(num * num);
        }

        return resultado;
    }

    private List<Integer> mostrarLista(List<Integer> numeros) {
        for (Integer num : numeros) {
            System.out.println(num);
        }

        return numeros;
    }

    private int sumarLista(List<Integer> numeros) {
        int total = 0;
        for (Integer num : numeros) {
            total = total + num;
        }
        return total;
    }
}
