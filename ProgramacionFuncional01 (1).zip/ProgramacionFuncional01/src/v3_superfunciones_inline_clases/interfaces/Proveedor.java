package v3_superfunciones_inline_clases.interfaces;

//¿Que es un Predicate en Java?
// Presentación con ejemplos del Predicado
public interface Proveedor {

    Integer obtener();
}
