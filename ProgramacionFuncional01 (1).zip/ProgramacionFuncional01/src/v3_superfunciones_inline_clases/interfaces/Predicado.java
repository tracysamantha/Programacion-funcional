package v3_superfunciones_inline_clases.interfaces;


//¿Que es un Proveedor en Java?
// Presentación con ejemplos del Supplier
public interface Predicado {

    public boolean test(Integer p);
}
