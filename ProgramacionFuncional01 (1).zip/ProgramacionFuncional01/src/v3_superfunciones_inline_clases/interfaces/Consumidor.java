package v3_superfunciones_inline_clases.interfaces;

//¿Que es un Consumer interface en Java?
// Presentación con ejemplos del Predicado
public interface Consumidor {
    void aceptar(Integer valor);
}
