package v4_superfunciones_genericas.interfaces;

public interface OperadorUniario <T> extends Function<T,T>{

}
