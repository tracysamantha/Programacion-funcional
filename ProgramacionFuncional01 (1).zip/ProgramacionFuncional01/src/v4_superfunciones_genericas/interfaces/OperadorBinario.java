package v4_superfunciones_genericas.interfaces;

public interface OperadorBinario<T> extends FuncionBinaria<T,T,T> {
}
