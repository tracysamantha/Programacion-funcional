package v4_superfunciones_genericas.interfaces;

//¿Que es un Function interface en Java?
// Presentación con ejemplos del Predicado
public interface Function<T,R> {

    R aplicar (T numero);
}
