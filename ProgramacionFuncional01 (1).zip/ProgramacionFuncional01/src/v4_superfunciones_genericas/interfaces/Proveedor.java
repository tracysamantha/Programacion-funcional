package v4_superfunciones_genericas.interfaces;

//¿Que es un Predicate en Java?
// Presentación con ejemplos del Predicado
public interface Proveedor<T> {

    T obtener();
}
