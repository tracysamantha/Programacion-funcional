package v6_encadenado;

import v6_encadenado.interfaces.*;

import java.util.List;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        new Main();

    }

    /*
                Flujo.proveer(3, new Proveedor<Integer>() {
                    @Override
                    public Integer obtener() {
                        return (int) (Math.random() * 100 + 1);
                    }
                })*/

    //Constructor
    public Main() {

        Integer total =

                new Flujo<Integer>(List.of(1,2,3,4,5,6,7,8)).filtrar(new Predicado<>() {
                    @Override
                    public boolean test(Integer p) {
                        return p % 2 == 0;
                    }
                }).transformar(new Function<Integer, Integer>() {  //OperadorUnario
                    @Override
                    public Integer aplicar(Integer numero) {
                        return numero * numero;
                    }
                }).actuar(new Consumidor<>() {
                    @Override
                    public void aceptar(Integer valor) {
                        System.out.println(valor);
                    }
                }).reducir(0, new OperadorBinario<Integer>() {
                    @Override
                    public Integer aplicar(Integer valor1, Integer valor2) {
                        return valor1 + valor2;
                    }
                });

        System.out.println("Reducción : " + total);

    }
}