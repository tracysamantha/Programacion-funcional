package v6_encadenado.interfaces;

//¿Que es un BiConsumer en Java?
// Presentación con ejemplos del BiConsumer
public interface FuncionBinaria<T, U, R> {

    R aplicar(T valor1, U valor2);
}
