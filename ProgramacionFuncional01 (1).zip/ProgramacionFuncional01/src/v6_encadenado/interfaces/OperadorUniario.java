package v6_encadenado.interfaces;

public interface OperadorUniario <T> extends Function<T,T> {

}
