package v6_encadenado.interfaces;


//¿Que es un Proveedor en Java?
// Presentación con ejemplos del Supplier
public interface Predicado<T> {

    public boolean test(T p);
}
