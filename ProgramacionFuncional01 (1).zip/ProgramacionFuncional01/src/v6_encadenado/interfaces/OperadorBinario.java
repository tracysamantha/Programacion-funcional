package v6_encadenado.interfaces;

public interface OperadorBinario<T> extends FuncionBinaria<T,T,T> {
}
