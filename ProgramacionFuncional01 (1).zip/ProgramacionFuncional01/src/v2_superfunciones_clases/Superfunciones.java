package v2_superfunciones_clases;

import v2_superfunciones_clases.interfaces.*;

import java.util.ArrayList;
import java.util.List;

public class Superfunciones {

    //Aquí puedo filtrar pares e impares
    public static List<Integer> filtrar(List<Integer> numeros, Predicado predicado) {
        List<Integer> resultado = new ArrayList<>();

        for (Integer numero : numeros) {
            if (predicado.test(numero)) {
                resultado.add(numero);
            }
        }

        return resultado;

    }

    public static List<Integer>
    proveer(int size, Proveedor proveedor) {
        List<Integer> resultado = new ArrayList<>();

        for (int i = 0; i < size; i++) {
            resultado.add(proveedor.obtener());
        }

        return resultado;

    }

    public static List<Integer> transformar(List<Integer> numeros, Function function) {
        List<Integer> resultado = new ArrayList<>();

        for (Integer numero : numeros) {
            resultado.add(function.aplicar(numero));
        }

        return resultado;

    }

    public static List<Integer> actuar(List<Integer> numeros, Consumidor consumidor) {
        for (Integer numero : numeros) {
            consumidor.aceptar(numero);
        }

        return numeros;

    }

    public static void consumir(List<Integer> numeros, Consumidor consumidor) {
        for (Integer numero : numeros) {
            consumidor.aceptar(numero);
        }
    }

    public static int reducir(List<Integer> numeros, Integer pivot, FuncionBinaria funcionBinaria) {
        int total = pivot;
        for (Integer numero : numeros) {
            total = funcionBinaria.aplicar(total, numero);
        }

        return total;
    }
}
