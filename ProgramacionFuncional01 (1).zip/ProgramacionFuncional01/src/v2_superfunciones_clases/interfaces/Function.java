package v2_superfunciones_clases.interfaces;

//¿Que es un Function interface en Java?
// Presentación con ejemplos del Predicado
public interface Function {

    Integer aplicar (Integer numero);
}
