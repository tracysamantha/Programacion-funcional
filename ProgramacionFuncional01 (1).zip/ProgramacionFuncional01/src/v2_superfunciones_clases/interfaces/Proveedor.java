package v2_superfunciones_clases.interfaces;

import java.util.List;

//¿Que es un Predicate en Java?
// Presentación con ejemplos del Predicado
public interface Proveedor {

    Integer obtener();

}
