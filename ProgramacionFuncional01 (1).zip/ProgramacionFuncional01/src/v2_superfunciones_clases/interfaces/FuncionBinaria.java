package v2_superfunciones_clases.interfaces;

//¿Que es un BiConsumer en Java?
// Presentación con ejemplos del BiConsumer
public interface FuncionBinaria {

    Integer aplicar(Integer valor1, Integer valor2);
}
