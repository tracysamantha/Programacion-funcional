package v2_superfunciones_clases.clases;

import v2_superfunciones_clases.interfaces.Function;

public class AlCuadrado implements Function {
    @Override
    public Integer aplicar(Integer numero) {
        return numero * numero;
    }
}
