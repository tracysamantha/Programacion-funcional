package v5_flujo;
import v5_flujo.interfaces.*;

import java.util.ArrayList;
import java.util.List;

//proveedor().filtrar().transformar().actuar().reducir()
//reducir(actuar(transformar(filtrar(proveedor())))))

public class Flujo<T> {

    private final List<T> valores;

    public Flujo(List<T> valores) {
        this.valores = valores;
    }

    public static <T> Flujo<T> proveer(int size, Proveedor<T> proveedor) {
        List<T> resultado = new ArrayList<>();

        for (int i = 0; i < size; i++) {
            resultado.add(proveedor.obtener());
        }

        return new Flujo<>(resultado);

    }

    //Aquí puedo filtrar pares e impares
    public Flujo<T> filtrar(Predicado<T> predicado) { // cualquier tipo de dato
        List<T> resultado = new ArrayList<>();

        for (T valor : valores) {
            if (predicado.test(valor)) {
                resultado.add(valor);
            }
        }

        return new Flujo<>(resultado);

    }


    public <R> Flujo<R> transformar(Function<T,R> function) {
        List<R> resultado = new ArrayList<>();

        for (T valor : valores) {
            resultado.add(function.aplicar(valor));
        }
        return new Flujo<>(resultado);
    }

    public Flujo<T> actuar(Consumidor<T> consumidor) {
        for (T valor : valores) {
            consumidor.aceptar(valor);
        }
        return new Flujo<>(valores);
    }

    public void consumir(Consumidor<T> consumidor) { //Operación terminal, luego no se podrá engachar con otro llamada porque no retorna nada
        for (T valor : valores) {
            consumidor.aceptar(valor);
        }
    }

    public T reducir(T pivot, OperadorBinario<T> funcionBinaria) { //Operación terminal, luego no se podrá engachar con otro llamada porque no retorna un flujo
        T total = pivot;
        for (T valor : valores) {
            total = funcionBinaria.aplicar(total, valor);
        }

        return total;
    }

    @Override
    public String toString() {
        return valores.toString();
    }
}
