package v5_flujo;

import v5_flujo.interfaces.*;

import java.util.List;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        new Main();

    }

    //Constructor
    public Main() {


        //proveedor().filtrar().transformar().actuar().reducir()
        //reducir(actuar(transformar(filtrar(proveedor())))))


        //1. Crear lista de enteros de manera aleatoria
        Flujo<Integer> numerosAzar = Flujo.proveer(3, new Proveedor<>() {
            @Override
            public Integer obtener() {
                return (int) (Math.random() * 100 + 1);
            }
        });

        System.out.println("1. Crear lista de enteros de manera aleatoria");
        System.out.println(numerosAzar);


        //2. Filtrar sólo los números pares
        Flujo<Integer> numerosPares = numerosAzar.filtrar(new Predicado<>() {
            @Override
            public boolean test(Integer p) {
                return p % 2 == 0;
            }
        });
        System.out.println("\n2. Filtrar sólo los números pares ");
        System.out.println(numerosPares);


        //3.1 Convertir los números al cuadrado
        Flujo<Integer> numerosCuadrados = numerosPares.transformar(new Function<Integer, Integer>() {  //OperadorUnario
            @Override
            public Integer aplicar(Integer numero) {
                return numero * numero;
            }
        });

        System.out.println("\n3.1. Convertir los números al cuadrado ");
        System.out.println(numerosCuadrados);

        //3.2 Obtener cada número convertido en cadena
        Flujo<String> convertidosEnCadena = numerosCuadrados.transformar(new Function<Integer, String>() {
            @Override
            public String aplicar(Integer numero) {
                return "valor en String: --> " + numero;
            }
        });
        System.out.println("\n3.2. Obtener cada número convertido en cadena ");
        System.out.println(convertidosEnCadena);

        ////////
        Consumidor<Integer> consumidor = new Consumidor<>() {
            @Override
            public void aceptar(Integer valor) {
                System.out.println(valor);
            }
        };

        System.out.println("\n4. Mostrar cada cuadrado por pantalla que retorna");
        //4.a Mostrar cada cuadrado por pantalla que retorna
        Flujo<Integer> numerosMostrados = numerosCuadrados.actuar(consumidor);


        //4.b Mostrar cada cuadrado por pantalla sin retorno
        numerosCuadrados.consumir(consumidor);

        //5. Obtener la suma de los cuadrados
        Integer sumatoria = numerosMostrados.reducir(0, new OperadorBinario<Integer>() {
            @Override
            public Integer aplicar(Integer valor1, Integer valor2) {
                return valor1 + valor2;
            }
        });//sumarLista(numerosMostrados);

        System.out.println("\n5. Obtener la suma de los cuadrados");
        System.out.println("Suma total : " + sumatoria);
    }
}