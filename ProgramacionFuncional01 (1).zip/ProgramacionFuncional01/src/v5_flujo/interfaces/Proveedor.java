package v5_flujo.interfaces;

//¿Que es un Predicate en Java?
// Presentación con ejemplos del Predicado
public interface Proveedor<T> {

    T obtener();
}
