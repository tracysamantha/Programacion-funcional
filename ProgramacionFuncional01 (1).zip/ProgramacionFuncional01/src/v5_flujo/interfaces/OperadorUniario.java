package v5_flujo.interfaces;

public interface OperadorUniario <T> extends Function<T,T> {

}
