package v5_flujo.interfaces;

//¿Que es un Consumer interface en Java?
// Presentación con ejemplos del Predicado
public interface Consumidor<T> {
    void aceptar(T valor);
}
