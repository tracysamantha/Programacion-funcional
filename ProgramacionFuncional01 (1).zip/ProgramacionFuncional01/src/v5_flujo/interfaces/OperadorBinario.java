package v5_flujo.interfaces;

public interface OperadorBinario<T> extends FuncionBinaria<T,T,T> {
}
